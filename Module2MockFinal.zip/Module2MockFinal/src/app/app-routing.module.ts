import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AddComponent } from './add/add.component';
import { ShowComponent } from './show/show.component';
import { SearchComponent } from './search/search.component';
import { DeleteComponent } from './delete/delete.component';


const routes: Routes = [
  {path:'',component:HomeComponent},
{path:'add', component:AddComponent},
{path:'show', component:ShowComponent},
{path:'search', component:SearchComponent},
{path:'delete', component:DeleteComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
