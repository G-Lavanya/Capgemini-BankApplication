import { Component, OnInit } from '@angular/core';
import { EmployeeService } from'../employee.service';
import { Router } from'@angular/router';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private ms:EmployeeService,private router:Router) { }
  employee;
  ngOnInit() {
  }
  getAll(){
    this. ms.getAll().subscribe((res)=>this.employee=res)
    }
  
    back(){
      this.router.navigate([''])
    }
}
