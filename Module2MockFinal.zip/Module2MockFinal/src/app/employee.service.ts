import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
 
@Injectable({
 providedIn: 'root'
})
export class EmployeeService {
 
 
 constructor(private http:HttpClient) { }
 add(employee){
 let opt = new HttpHeaders({'Content-Type':'application/json'})
 return this.http.post('http://localhost:3000/employees',employee,{headers:opt})
 }
 getAll(){
 return this.http.get('http://localhost:3000/employees')
 }
 remove(mid){
 return this.http.delete('http://localhost:3000/employees/'+mid)
 }
}