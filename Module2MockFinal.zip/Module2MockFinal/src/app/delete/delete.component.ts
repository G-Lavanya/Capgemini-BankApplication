import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from'@angular/router';
@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

 constructor(private ms:EmployeeService,private router:Router) { }
 

 removeEmployee(id){
  this.ms.remove(id).subscribe(()=>{
  alert('deleted...')
  history.go(); 
  })
  }
back(){
  this.router.navigate([''])
}

 
 ngOnInit() {
 }
 
}
