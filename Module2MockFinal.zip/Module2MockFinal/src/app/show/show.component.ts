import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
 
@Component({
 selector: 'app-show',
 templateUrl: './show.component.html',
 styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
 mobiles;
 constructor(private ms:EmployeeService) { 
 ms.getAll().subscribe((res) => this.mobiles=res)
 }
 removeMobile(id){
 this.ms.remove(id).subscribe(()=>{
 alert('deleted...')
 history.go(); 
 })
 }
 
 ngOnInit() {
 }
 
}