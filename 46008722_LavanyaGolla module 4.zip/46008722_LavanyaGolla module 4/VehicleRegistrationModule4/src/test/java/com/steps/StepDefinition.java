package com.steps;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import com.registrationpom.EducationDetails;
import com.registrationpom.PresonalDetails;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	WebDriver driver;
	VehicleDetails Details;
	EducationDetails education;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\LAVGOLLA\\Downloads\\chromedriver.exe");
		   driver=new ChromeDriver();
		  Details=new VehicleDetails(driver);
		
	}
	
	@Given("^User is on Registration Page for Vehicle Registration$")
	public void user_is_on_Registration_Page_for_Vehicle_Registration() throws Throwable {
	    driver.get("C:\\Users\\LAVGOLLA\\Downloads\\Selenium BDD\\46008722_Lavanya\\46007573_bangar raju_chopperla_m4 (1)\\46007573_bangar raju_chopperla_m4\\registration_form\\src\\test\\java\\com\\registrationpom\\VehicleRegistrationForm.html");
	  //  throw new PendingException();
	}
	
	@Then("^the title should be Welcome to VehicleRegistration$")
	public void the_title_should_be_Welcome_to_VehicleRegistration() throws Throwable {
		String title = driver.getTitle();
		assertEquals("Welcome to VehicleRegistration", title);
	}
	
	@When("^Submit link  is clicked without entering the title$")
	public void submit_link_is_clicked_without_entering_the_title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//
		Details.Submit().click();
	}

	

	@Then("^error message should be displayed as 'Select title from the list'$")
	public void error_message_should_be_displayed_as_Select_title_from_the_list() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Select title from the list", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^Submit link is clicked without entering the ownername$")
	public void submit_link_is_clicked_without_entering_the_ownername() throws Throwable {
		Details.title("Ms").click();
		Details.Submit().click();
	}


	@Then("^error message should be displayed as 'Owner Name should not be empty and must contain alphabets with in the range of (\\d+) to (\\d+)'$")
	public void error_message_should_be_displayed_as_Owner_Name_should_not_be_empty_and_must_contain_alphabets_with_in_the_range_of_to(int arg1, int arg2) throws Throwable {
		Alert alert=driver.switchTo().alert();
		//assertEquals("Owner Name should not be empty and must contain alphabets with in the range of 5 to 10", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^Submit link is clicked without entering the gender$")
	public void submit_link_is_clicked_without_entering_the_gender() throws Throwable {
		Details.OwnerName().sendKeys("lavanya");
	//	Details.OwnerName().sendKeys("lavanya");
		  Details.Submit().click();
	}

	@Then("^error message should be displayed as 'Please Select gender'$")
	public void error_message_should_be_displayed_as_Please_Select_gender() throws Throwable {
		Alert alert=driver.switchTo().alert();
		//assertEquals("Please Select gender", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^Submit link is clicked without entering the address$")
	public void submit_link_is_clicked_without_entering_the_address() throws Throwable {
//		 List<WebElement> list=driver.findElements(By.id("gender"));
//		    Iterator<WebElement> i=list.iterator();
//		    while(i.hasNext()) {
//		        WebElement element=i.next();
//		        String name=element.getAttribute("name");
//		        if(name.equalsIgnoreCase("Female")) {
//		            element.click();
//		        }
//		        
//		    }
		Details.Submit().click();
	}
	
	@Then("^error message should be displayed as 'Address should not be empty and must contain alphabets with in the range of (\\d+) to (\\d+)'$")
	public void error_message_should_be_displayed_as_Address_should_not_be_empty_and_must_contain_alphabets_with_in_the_range_of_to(int arg1, int arg2) throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Address should not be empty and must contain alphabets with in the range of 5 to 10", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}
	@When("^Submit link is clicked without entering the city$")
	public void submit_link_is_clicked_without_entering_the_city() throws Throwable {
		 Details.address().sendKeys("Bhel Hyderabad");
		   Details.Submit().click();
	}

	@Then("^error message should be displayed as 'city should not be empty and must have alphabet characters only'$")
	public void error_message_should_be_displayed_as_city_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("city should not be empty and must have alphabet characters only", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^Submit Link is clicked without selecting the State$")
	public void submit_Link_is_clicked_without_selecting_the_State() throws Throwable {
		 Details.city().sendKeys("Hyderabad");
		  Details.Submit().click();
	}

	@Then("^error message should be displayed as 'State should not be empty and must have alphabet characters only'$")
	public void error_message_should_be_displayed_as_State_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("state should not be empty and must have alphabet characters only", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^Submit Link is clicked without selecting  the Country$")
	public void submit_Link_is_clicked_without_selecting_the_Country() throws Throwable {
		Details.city().sendKeys("Telangana");
		  Details.Submit().click();
	}

	@Then("^error message should be displayed as 'Country should not be empty and must have alphabet characters only'$")
	public void error_message_should_be_displayed_as_Country_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("country should not be empty and must have alphabet characters only", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^Submit Link is clicked without selecting  the Zip Code$")
	public void submit_Link_is_clicked_without_selecting_the_Zip_Code() throws Throwable {
		Details.country("India").click();
		Details.Submit().click();
	}

	@Then("^error message should be displayed as 'ZIP code should not be empty and must have (\\d+) numeric characters only'$")
	public void error_message_should_be_displayed_as_ZIP_code_should_not_be_empty_and_must_have_numeric_characters_only(int arg1) throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("ZIP code should not be empty and must have 6 numeric characters only", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^Submit Link is clicked without selecting  the vehicle type$")
	public void submit_Link_is_clicked_without_selecting_the_vehicle_type() throws Throwable {
		Details.city().sendKeys("502032");
		  Details.Submit().click();
	}

	@Then("^error message should be displayed as 'Please Select Vehicle type'$")
	public void error_message_should_be_displayed_as_Please_Select_Vehicle_type() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please Select Vehicle type", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^Submit Link is clicked without selecting  the fueltype$")
	public void submit_Link_is_clicked_without_selecting_the_fueltype() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@Then("^error message should be displayed as 'Please Select fueltype'$")
	public void error_message_should_be_displayed_as_Please_Select_fueltype() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please Select fueltype", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^Submit Link is clicked without selecting  the year of mfg$")
	public void submit_Link_is_clicked_without_selecting_the_year_of_mfg() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@Then("^error message should be displayed as 'Select the mfg year from the list'$")
	public void error_message_should_be_displayed_as_Select_the_mfg_year_from_the_list() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Select the mfg year from the list", alert.getText());
		  Thread.sleep(1500);
		alert.accept();
	}

	@When("^User enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		Details.mfg("2015").click();
		  Details.Submit().click();
	}

	@Then("^User clicks Submit$")
	public void user_clicks_Submit() throws Throwable {
		 Details.Submit().click();
		 driver.close();
	}
}
