package com.steps;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class VehicleDetails {

	WebDriver driver;

	public VehicleDetails(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(xpath = "/html/body/form/ul/li[26]/input")
	WebElement Submit;

	@FindBy(xpath = "/html/body/form/ul/li[2]/select")
	WebElement title;

	@FindBy(id ="ownername")
	WebElement OwnerName;
	
	@FindBy(id ="address")
	WebElement address;

	
	@FindBy(id = "city")
	WebElement city;
	
	@FindBy(id = "state")
	WebElement state;
	@FindBy(id = "zip")
	WebElement zip;
	
	@FindBy(xpath ="/html/body/form/ul/li[15]/select")
	WebElement country;
	
	
	@FindBy(xpath ="/html/body/form/ul/li[25]/select")
	WebElement mfg;
	
	
	
	public WebElement Submit() {
		return Submit;
	}

	public WebElement title(String s) {
		Select select = new Select(title);
		select.selectByValue(s);
		return title;
	}

	public WebElement OwnerName() {

		return OwnerName;
	}

	public WebElement address() {
		
		return address;
	}

	public WebElement city() {
		return city;
	}
	
	public WebElement zip() {
		return zip;
	}
	
	public WebElement state() {
		return state;
			}

	public WebElement country(String s) {
		Select select = new Select(country);
		select.selectByValue(s);
		return country;
	}

	public WebElement mfg(String s) {
		Select select = new Select(mfg);
		select.selectByValue(s);
		return mfg;
	}

}
