package com.registrationpom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PresonalDetails {
	WebDriver driver;
	
	public PresonalDetails(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[11]/td/a")
	WebElement next;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[1]/td[2]/input")
	WebElement firstname;
	
	@FindBy(xpath="//*[@id=\"txtLastName\"]")
	WebElement lastname;
	
	@FindBy(xpath="//*[@id=\"txtEmail\"]")
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"txtPhone\"]")
	WebElement phone;
		
	@FindBy(xpath="//*[@id=\"txtAddress1\"]")
	WebElement address1;
	
	@FindBy(xpath="//*[@id=\"txtAddress2\"]")
	WebElement address2;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]/select")
	WebElement city;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[10]/td[2]/select")
	WebElement state;
	
	
	public WebElement next()
	{
		return next;	
	}
	
	
	public WebElement firstname()
	{
		return firstname;
	}
	
	
	public WebElement lastname()
	{
		return lastname;
	}
	
	public WebElement email()
	{
		return email;
	}
	public WebElement phone()
	{
		return phone;
	}
	public WebElement getPhone() {
		return phone;
	}
	public WebElement address1()
	{
		return address1;
	}
	
	public WebElement address2()
	{
		return address2;
	}
	
	public WebElement city(String s)
	{
		Select select=new Select(city);
        select.selectByValue(s);
		return city;
	}
	
	public WebElement state(String s)
	{
		Select select=new Select(state);
        select.selectByValue(s);
		return state;
	}
	
	

}
