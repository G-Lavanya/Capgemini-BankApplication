/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: Customer Service Layer Interface Class
 */
package com.cg.service;

import com.cg.beans.Customer;

public interface ICustomerService {

	public Customer addCustomer(Customer customer);
	public boolean getBalance(int accno);
	public boolean deposit(int amt,int accNo);
	public boolean withdrawAmt(int amt,int accNo);
	public boolean fundTransfer(int amt,int acc1,int acc2);
	public boolean recentTransactions(int accNo);
	public boolean isValidName(String name);
	public boolean isValidEmailId(String emailId);
	public boolean isValidNumber(String cellno);
	
}
