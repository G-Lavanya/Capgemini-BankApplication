/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: Utility class
 */
package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.beans.Customer;

public class CustomerData {

	static public Map<Integer, Customer> hm=new HashMap<>();
	
	static
	{
		hm.put(7493,  new Customer("Lavanya", "96665858625", "lavanya@gmail.com", 7493, 660f));
		hm.put(1234,  new Customer("Pooja", "7674810556", "pooja@gmail.com", 1234, 18560f));
				
	}
	
}
