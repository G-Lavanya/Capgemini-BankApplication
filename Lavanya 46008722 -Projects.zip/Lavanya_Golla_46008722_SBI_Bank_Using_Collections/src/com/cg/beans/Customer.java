/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: Customer POJO Class
 */
package com.cg.beans;

public class Customer {

	private String name;
	private String cellno;
	private String emailId;
	
	private int accountNo;
	private double balance=0f;
	private String[] transactions =new String[5];
	
	//constructor without fields
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//constructor with fields
	public Customer(String name, String cellno, String emailId, int accountNo, double balance) {
		super();
		this.name = name;
		this.cellno = cellno;
		this.emailId = emailId;
		
		this.accountNo = accountNo;
		this.balance = balance;
	}
	
	//getters and setters
	public String getName() {
		return name;
	}
	

	public void setName(String name) {
		this.name = name;
	}
	public String getCellno() {
		return cellno;
	}
	public void setCellno(String cellno) {
		this.cellno = cellno;
	}
	
	
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the transactions
	 */
	public void getTransactions() {
		for(int i=0;i<5;i++)
		{
			if(this.transactions[i]==null)
				System.out.println((i+1)+"              N/A            N/A");
			else
			    System.out.println((i+1)+this.transactions[i]);
		}
		
	}

	/**
	 * @param transactions the transactions to set
	 */
	public void setTransactions(String transactions) {
		if(this.transactions[4]==null)
		for(int i=0;i<5;i++)
		{
			if(this.transactions[i]==null)
			{
				this.transactions[i]=transactions;
				break;
			}			
		}
		else
		{
			for (int j = 0; j < 5; j++) {
				this.transactions[j]=this.transactions[j+1];
			}
			this.transactions[4]=transactions;
		}
	}
	
	
	
}
