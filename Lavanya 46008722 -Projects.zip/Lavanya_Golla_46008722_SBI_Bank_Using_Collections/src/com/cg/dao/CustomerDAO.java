/**
 * 
 *@Author: G.LAVANYA	

 *
 *Date :18/10/2019
 *
 *Description: Customer Dao Class	
 */




package com.cg.dao;

import com.cg.beans.Customer;
import com.cg.util.CustomerData;

public class CustomerDAO implements ICustomerDAO{

	@Override
	public Customer addCustomer(Customer customer) {
		CustomerData.hm.put(customer.getAccountNo(), customer);
		return null;
	}

	@Override
	public boolean getBalance(int accno) {
		if(CustomerData.hm.containsKey(accno))
		{
			Customer customer=CustomerData.hm.get(accno);
			double bal=customer.getBalance();
			System.out.println("Your current balance is: "+bal);
			return true;
		}
		else
			System.out.println("invalid account number");
		return false;
	}

	@Override
	public boolean deposit(int amt, int accNo) {
		if(amt>0 && CustomerData.hm.containsKey(accNo))
		{
			 Customer customer= CustomerData.hm.get(accNo);
			 customer.setBalance(customer.getBalance()+amt);
			 System.out.println("Amount deposited successfully, final amount is: "+customer.getBalance());
			 customer.setTransactions("           Credited          "+amt);
			 return true;
			
		}
		else if(amt<0 && !(CustomerData.hm.containsKey(accNo)))
			System.out.println("Ivalid amount and account not found try again");
		else if (amt<0)
			System.out.println("Invalid amount try again");
		else
			System.out.println("Account not found try again");
		
		return false;
	}

	@Override
	public boolean withdrawAmt(int amt, int accNo) {
		if(!CustomerData.hm.containsKey(accNo))
		{
			System.out.println("Invalid account nuber.  Try again");
			System.out.println("");
			return false;
		}
		
		else {
			Customer customer=CustomerData.hm.get(accNo);
			if(amt>customer.getBalance())
			{
				System.out.println("Funds not available, try again with lesser amount");
				System.out.println("");
				return false;
			}
			else
			{

				customer.setBalance(customer.getBalance()-amt);
				System.out.println("Amount withdrawn");
				System.out.println("available funds: "+customer.getBalance());
				customer.setTransactions("           Debited           "+amt);
				return true;
			}
		}
	}

	@Override
	public boolean fundTransfer(int amt, int acc1, int acc2) {
		this.withdrawAmt(amt, acc1);
		this.deposit(amt, acc2);
		if(!CustomerData.hm.containsKey(acc1)&& !CustomerData.hm.containsKey(acc2))
		{
			System.out.println("Invalid account number!  Try again");
			System.out.println("");
			return false;
		}
		else {
		System.out.println("Funds transferred successfully");
		
		return true;
		}
	}

	@Override
	public boolean recentTransactions(int accNo) {
		if(CustomerData.hm.containsKey(accNo)){ 
		Customer customer= CustomerData.hm.get(accNo);
		 System.out.println("your recent transactions are");
		 System.out.println("");
		 System.out.println("");
		 System.out.println("S.No    Transaction Type    Amount");
		 System.out.println("___________________________________");
		 customer.getTransactions();
		 return true;
		}
		else{
			System.out.println("Invalid account nuber.  Try again");
			System.out.println("");
			return false;
		}
		
	}

	
	
}
