/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: Testing the Customer DAO
 */
package com.cg.test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

 

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

 

import com.cg.beans.Customer;
import com.cg.dao.CustomerDAO;
import com.cg.service.CustomerService;

 

class CustomerDAOTest {
     Customer c,c1;
       static CustomerDAO customerDAO;
       
    @BeforeEach
    void setUp() throws Exception {
          customerDAO = new CustomerDAO();
           c = new Customer("Yamini", "96665858625", "yaminiambati1997@gmail.com", 7493, 660f);
           c1 = new Customer("Yamini", "96665858625", "yaminiambati1997@gmail.com", 7493, 660f);
           customerDAO.addCustomer(c);
           customerDAO.addCustomer(c1);
    }

 

    @AfterEach
    void tearDown() throws Exception {
        customerDAO= null;
        c= null;
        c1 = null;
    }
    
    
    @Test
    void testgetBalance() {
           assertEquals(true, customerDAO.getBalance(7493));
    }
    
    
    @Test
    void testDeposit() {
           assertEquals(true, customerDAO.deposit(660, 7493));
    }
    
    @Test
    void testWithdrawAmt() {
           assertEquals(true, customerDAO.withdrawAmt(660, 7493));
    }
    
    @Test
    void testFundTransfer() {
           assertEquals(true, customerDAO.fundTransfer(60, 7493, 7481));
    }
    
    @Test
    void testrecentTranscations() {
           assertEquals(true, customerDAO.recentTransactions(7493));
    }

 

}