/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :12/05/2019
 *
 *Description: Client class, which is front end part of the project
 */

package com.plp.springjpa.client;

import java.util.List;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.plp.springjpa.entity.Transaction;
import com.plp.springjpa.service.BankServiceImpl;

public class Client {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
		BankServiceImpl bankService = ctx.getBean("bankService", BankServiceImpl.class);
		int option;
		int obj, balance;
		String name, pswd, contactNo;
		while (true) {
			System.out.println("*****************************");
			System.out.println("<<<<<<<<<<<< Welcome to XYZ bank!!! >>>>>>>>>>>>");
			System.out.println("Please Selcet Your Option...");
			System.out.println("1.Create an Account");
			System.out.println("2.Balance Check");
			System.out.println("3.Money Deposit");
			System.out.println("4.Money Withdrawl");
			System.out.println("5.Money Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Welcome to XYZ Bank");
				do {
					System.out.println("Enter your name: ");
					name = scan.next();
					obj = bankService.nameValidate(name);
				} while (obj != 1);
				do {
					System.out.println("Enter your mobile number: ");
					contactNo = scan.next();
					obj = bankService.mobNoValidate(contactNo);
				} while (obj != 1);
				long accNo = (long) (Math.random() * 1234);
				do {
					System.out.println("Create 4 digit Pin: ");
					pswd = scan.next();
					obj = bankService.passwordValidate(pswd);
				} while (obj != 1);
				do {
					System.out.println("Enter the amount: ");
					balance = scan.nextInt();
					obj = bankService.checkBalance(balance);
				} while (obj != 1);
				boolean result = bankService.createAccount(name, contactNo, pswd, accNo, balance);
				if (result) {
					System.out.println("Your Account has been created successfully: " + accNo);
				}
				break;
			case 2:
				System.out.println("Enter the account number: ");
				accNo = scan.nextLong();
				System.out.println("Enter your 4 digit Pin");
				pswd = scan.next();
				boolean bank1 = bankService.validateAccount(accNo, pswd);
				if (bank1) {
					balance = bankService.showBalance(accNo);
					if (balance != 0) {
						System.out.println("Your Current account balance is: " + balance);
					} else {
						System.out.println("Error Occured:");
					}
				} else {
					System.out.println("The details you have entered are invalid..Check once again..");
				}
				break;

			case 3:
				System.out.println("Enter your account number");
				accNo = scan.nextLong();
				System.out.println("Enter your 4 digit Pin");
				pswd = scan.next();
				boolean bank2 = bankService.validateAccount(accNo, pswd);
				if (bank2) {
					System.out.println("Enter the amount to be deposited");
					int deposit = scan.nextInt();
					balance = bankService.depositAmount(accNo, deposit);
					System.out.println("Amount is deposited to your account");
					System.out.println("your current balance is " + balance);
				} else {
					System.out.println("The details you have entered are invalid..Check once again..");
				}
				break;

			case 4:
				System.out.println("Enter your account number");
				accNo = scan.nextLong();
				System.out.println("Enter your 4 digit Pin");
				pswd = scan.next();
				bank2 = bankService.validateAccount(accNo, pswd);
				if (bank2) {
					balance = bankService.showBalance(accNo);
					System.out.println("Your current balance is " + balance);
					System.out.println("Enter the amount to be withdraw");
					int withdraw = scan.nextInt();
					balance = bankService.withdrawAmount(accNo, withdraw);
					if (balance >= 0) {
						System.out.println("Amount has been withdrawan from your account...");

						System.out.println("Your new account balance is " + balance + "\n");
					} else {
						System.out.println("Insufficient Balance..");
					}
				}

				else {
					System.out.println("The details you have entered are invalid..Check once again..");
				}
				break;

			case 5:
				System.out.println("Enter the senders account number");
				accNo = scan.nextLong();
				System.out.println("Enter your 4 digit Pin");
				pswd = scan.next();
				bank2 = bankService.validateAccount(accNo, pswd);
				if (bank2) {
					System.out.println("\nEnter the receivers account transfer");
					long accno = scan.nextLong();
					System.out.println("Enter the amount you want to transfer");
					int amount = scan.nextInt();
					boolean transfer = bankService.fundTransfer(accNo, accno, amount);
					if (transfer) {
						System.out.println(amount + " amount has been transferred successfully...");
					} else {
						System.out.println("Problem Occurred During transaction...");
					}
				} else {
					System.out.println("The details you have entered are invalid..Check once again..");
				}
				break;

			case 6:
				System.out.println("Enter your account number");
				accNo = scan.nextLong();
				System.out.println("Enter your 4 digit Pin");
				pswd = scan.next();
				bank2 = bankService.validateAccount(accNo, pswd);
				if (bank2) {
					List<Transaction> trans = bankService.getTransaction(accNo);

					System.out.println("----------Transaction Statement----------\n");

					for (Transaction tran : trans) {
						System.out.println(tran);
					}
				} else {
					System.out.println("The details you have entered are invalid..Check once again..");
				}
				break;

			case 7:
				System.out.println("**********Thank you for using our Bank Services***********");
				System.out.println("**********Looking Forward for your presence***********");
				System.exit(0);
				break;

			default:
				System.out.println("kindly select the existing options......");
				break;
			}
		}
	}
}
