/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: USER INTERFACE	
 */
package com.cg.ebank.view;

import java.util.Scanner;

import com.cg.ebank.service.AccountController;
import com.cg.ebank.service.AccountInterface;

public class MainBank {

	public static void main(String[] args) {

		/*
		 * use Scanner class for taking inputs use switch case & while loop for Yes/No
		 */

		AccountInterface account = new AccountController();
		Scanner scan = new Scanner(System.in);
		int key = 0;
		int choice = 0;
		System.out.println("***************Welcome to IDFC Bank Customer Portal*****************");
		do {

			System.out.println("Select any option: ");
			System.out.println("1. Create Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit Amount");
			System.out.println("4. Withdraw Amount");
			System.out.println("5. Transfer Fund");
			System.out.println("6. Print Transaction");
			System.out.println("7. View Account Details");
			key = scan.nextInt();
			switch (key) {
			case 1:
				account.createAccount();
				break;
			case 2:
				account.showBalance();
				break;
			case 3:
				account.depositAmount();
				break;
			case 4:
				account.withdrawAmount();
				break;
			case 5:
				account.transferFund();
				break;
			case 6:
				account.printTransaction();
				break;
			case 7:
				account.viewCustomerDetails();
				break;
			default:
				System.out.println("Invalid Key");
				break;
			}
			System.out.println("Do you want to continue? \n1. Yes \n2. No");
			choice = scan.nextInt();

		} while (choice == 1);

	}

}