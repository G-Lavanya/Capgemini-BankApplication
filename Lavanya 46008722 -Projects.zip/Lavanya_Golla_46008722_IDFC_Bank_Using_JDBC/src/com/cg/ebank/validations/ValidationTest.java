/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: Junit test cases are invoked here.	
 */

package com.cg.ebank.validations;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import org.junit.Test;

import com.cg.ebank.dao.DAOClass;
import com.cg.ebank.dao.IDao;

public class ValidationTest {
	private Connection con;
	private PreparedStatement preparedstatement;
	IDao idao;
	Validations valid;
	private ResultSet resultset;
	Scanner sc = new Scanner(System.in);

	@Test
	public void testCheckExistence() {
		// fail("Not yet implemented");
		valid = new Validations();
		System.out.println("Enter accountId");
		int accountId = sc.nextInt();
		int flag = 1;
		int status = valid.checkExistence(accountId);
		// System.out.println(status);
		assertEquals(flag, status);
	}

	/*
	 * public void testCheckPhoneNumber() { //fail("Not yet implemented"); valid=new
	 * Validations(); System.out.println("Enter PhoneNumber: "); int
	 * phoneNumber=sc.nextInt(); int flag= 1; int
	 * status=valid.checkPhoneNumber(phoneNumber); System.out.println(status);
	 * assertEquals(flag,status); }
	 */

	@Test
	public void testCheckName() {
		valid = new Validations();
		System.out.println("Enter Name: ");
		String Name = sc.next();
		int flag = 1;
		int status = valid.checkName(Name);
		// System.out.println(status);
		assertEquals(flag, status);
	}

	@Test
	public void testCheckAmount() {
		valid = new Validations();
		System.out.println("Enter amount: ");
		int amount = sc.nextInt();
		int flag = 1;
		int status = valid.checkAmount(amount);
		// System.out.println(status);
		assertEquals(flag, status);
	}

}
