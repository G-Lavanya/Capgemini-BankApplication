/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: Validations class, the methods required for validation are written here.	
 */
package com.cg.ebank.validations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ebank.helper.DBConnection;
import com.cg.ebank.view.MainBank;

public class Validations extends RuntimeException {

	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	Pattern pattern;
	Matcher matcher;
	Validations validation;

	public int checkExistence(int accountId) {
		con = DBConnection.getConnection();
		validation = new Validations();
		
		System.out.println(accountId);
		int l = 1;
		try {
			ps = con.prepareStatement("select * from account where accountid =" + accountId);
			rs = ps.executeQuery();
			if (rs.next() != true) {
				l = 0;
				
				// System.exit(0);
				 throw validation;

				//return l;
			}return l;
		} catch (Validations i) {
		i.printStackTrace();
			System.err.println("Invalid Account Number!!\n Please Try Again with Correct Account Number");
			//MainBank.main(null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return l;
	}

	public int checkPhoneNumber(long custPhoneNum) {
		validation = new Validations();
		int l = 1;
		try {
			pattern = Pattern.compile("[6-9]{1}[0-9]{9}$");
			matcher = pattern.matcher(String.valueOf(custPhoneNum));
			if (!(matcher.matches())) {
				l = 0;
				System.err.println("Please enter a valid contact number");
				throw validation;
				
			}return l;
		} catch (Validations e) {
			e.printStackTrace();
			//PhoneNumberException.printStackTrace();

			//MainBank.main(null);
		}
		return l;
	}

	public int checkName(String custname) {
		validation = new Validations();
		int l = 1;
		try {
			pattern = Pattern.compile("([A-Z]){1}([a-z])*$");
			matcher = pattern.matcher(custname);
			if (!(matcher.matches())) {
				l = 0;
				System.err.println("Please enter a proper name");
				 throw validation;
				//return l;
			}return l;
		} catch (Validations e) {
			e.printStackTrace();
			

			//MainBank.main(null);
		}
		return l;
	}

	public int checkAmount(int Amount) {
		validation = new Validations();
		int l = 1;
		try {

			if (Amount % 100 != 0) {
				l = 0;
				System.err.println("Trasaction failed !!! ");
				System.err.println("Please the amount in multiples of 100");
				//return l;
				 throw validation;

			}return l;
		} catch (Validations CheckAmountException) {
			CheckAmountException.printStackTrace();
			// return 0;
			//MainBank.main(null);
		}

		return l;
	}

}
