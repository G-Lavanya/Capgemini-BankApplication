/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: SERVICE LAYER INTERFACE	
 */
package com.cg.ebank.service;

public interface AccountInterface {

	void showBalance();

	void depositAmount();

	void withdrawAmount();

	void transferFund();

	void printTransaction();

	void createAccount();

	void viewCustomerDetails();

}