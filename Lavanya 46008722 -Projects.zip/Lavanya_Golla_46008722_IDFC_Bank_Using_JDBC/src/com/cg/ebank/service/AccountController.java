/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: SERVICE LAYER 
 */
package com.cg.ebank.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.ebank.dao.DAOClass;
import com.cg.ebank.dao.IDao;
import com.cg.ebank.model.Account;
import com.cg.ebank.model.Customer;
import com.cg.ebank.model.Transaction;
import com.cg.ebank.validations.Validations;

public class AccountController implements AccountInterface {

	Scanner scan = new Scanner(System.in);
	IDao dao;
	Account account;
	Customer customer;
	double availablebal;
	double receiverbal;
	Validations valid = new Validations();
	String str1 = "savings";
	String str2 = "current";

	@Override
	public void createAccount() {
		System.out.println("Enter your name: ");
		String custName = scan.next();
		valid.checkName(custName);
		System.out.println("Enter your phone number: ");
		long custPhoneNum = scan.nextLong();
		valid.checkPhoneNumber(custPhoneNum);

		System.out.println("Enter your Account Type: ");
		String accType = scan.next();
		while (!accType.equals(str1) && (!accType.equals(str2))) {
			System.err.println("Invalid....!, please enter valid account Type");
			accType = scan.next();
		}
		System.out.println("Enter amount : ");
		double accBalance = scan.nextDouble();

		customer = new Customer();
		customer.setCustPhoneNum(custPhoneNum);
		customer.setCustName(custName);

		account = new Account();
		account.setAccountholdername(custName);
		account.setAccountType(accType);
		account.setBalance(accBalance);

		dao = new DAOClass();
		int status = dao.createCustomer(customer, account);
		if (status == 1) {
			System.out.println("Your Account has been created.");
		} else {
			System.out.println("Please try some other time.");
		}
	}

	public void viewCustomerDetails() {

		dao = new DAOClass();
		String custName = null;
		long custPhoneNum = 0;
		customer = new Customer();
		account = new Account();
		System.out.println("Enter Account Id: ");
		int accountId = scan.nextInt();
		ArrayList custList = dao.getAllCustomer(accountId);
		ArrayList accList = dao.getAllAccountDetails(accountId);
		// ArrayList transactionList = dao.getAllTransactionDetails(accountId);
		System.out.println(accList);
		System.out.println(custList);

	}

	@Override
	public void showBalance() {
		System.out.println("ENTER ACCOUNT ID");
		int accountId = scan.nextInt();
		if (valid.checkExistence(accountId) == 1) {
			dao = new DAOClass();
			System.out.println("Your Account Balance is Rs. " + dao.showBalance(accountId));
		}
	}

	public void depositAmount() {
		dao = new DAOClass();
		System.out.println("Enter your Account ID: ");
		int accountId = scan.nextInt();
		if (valid.checkExistence(accountId) == 1) {
			System.out.println("Enter amount to deposit:");
			int amt = scan.nextInt();

			String transactiontype = "credit";
			account = new Account();

			availablebal = account.getUpdatingAmount(amt, dao.showBalance(accountId));
			account.setBalance(availablebal);
			double status = dao.updateBalance(amt, accountId, availablebal, transactiontype);

			if (status != 0) {
				System.out.println("Rs." + amt + " is credited to your account.");
				System.out.println("Total Balance: Rs." + availablebal);
			} else {
				System.out.println("Something is wrong with your bank server");
			}
		}
	}

	@Override
	public void withdrawAmount() {
		dao = new DAOClass();
		account = new Account();
		System.out.println("Enter your Account ID: ");
		int accountId = scan.nextInt();
		if (valid.checkExistence(accountId) == 1) {
			System.out.println("Enter amount to withdraw:");
			int amt = scan.nextInt();
			if (valid.checkAmount(amt) == 1) {
				String transactiontype = "debit";
				account = new Account();

				if (dao.showBalance(accountId) > amt) {
					availablebal = account.getBalanceafterDeduction(amt, dao.showBalance(accountId));
					double status = dao.updateBalance(amt, accountId, availablebal, transactiontype);

					if (status != 0) {
						System.out.println("Rs." + amt + " is debited from your account.");
						System.out.println("Total Balance: Rs." + availablebal);
					} else {
						System.out.println("Something is wrong with your bank server");
					}
				} else {
					System.out.println("You don't have enough balance in your account");
				}
			}
		}
	}

	@Override
	public void transferFund() {
		dao = new DAOClass();
		account = new Account();
		System.out.println("Enter your Account ID: ");
		int accountId = scan.nextInt();
		if (valid.checkExistence(accountId) == 1) {
			System.out.println("Enter receiver Account ID: ");
			int receiverId = scan.nextInt();
			if (valid.checkExistence(accountId) == 1) {
				System.out.println("Enter amount you want to transfer:");
				int amt = scan.nextInt();
				if (valid.checkAmount(amt) == 1) {
					String transactiontype = " ";
					double updatedBal = 0;
					availablebal = dao.showBalance(accountId);
					if (availablebal >= amt) {
						updatedBal = account.getBalanceafterDeduction(amt, availablebal);
						transactiontype = "transfer";
						dao.updateBalance(amt, accountId, updatedBal, transactiontype);
						receiverbal = account.getUpdatingAmount(amt, dao.showBalance(receiverId));
						transactiontype = "received";
						dao.updateBalance(amt, receiverId, receiverbal, transactiontype);
						System.out.println("Transaction Successfull!!!");
					} else {
						System.err.println("Transaction failed!!!!");
					}

				}
			}
		}

	}

	@Override
	public void printTransaction() {
		dao = new DAOClass();
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Account Id: ");
		int accountId = scan.nextInt();
		if (valid.checkExistence(accountId) == 1) {
			ArrayList transactionList = dao.getAllTransactionDetails(accountId);
			System.out.println(transactionList);
		}
	}
}
