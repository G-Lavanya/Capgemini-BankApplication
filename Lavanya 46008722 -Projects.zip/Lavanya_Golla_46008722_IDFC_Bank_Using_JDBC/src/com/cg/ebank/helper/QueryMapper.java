/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: QUERY MAPPER CLASS
 */
package com.cg.ebank.helper;

import java.util.Random;

public class QueryMapper {
	 Random rand = new Random();
	 long accountid =(long) ((Math.random()*100)* rand.nextInt(1000));
	private static String accountId;
	public static final String INSERT_ACCOUNTDETAILS = "select * from Account where accountid = ";
	public static final String INSERT_CUSTOMERS = "select * from Customers where accountId = ";
	public static final String SHOW_BALANCE ="select Balance from Account where AccountId=";
	
	
}
  