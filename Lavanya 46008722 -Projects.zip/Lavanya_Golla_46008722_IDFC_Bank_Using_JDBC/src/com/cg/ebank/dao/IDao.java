/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: Dao Interface of Dao Class.
 */
package com.cg.ebank.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.ebank.model.Account;
import com.cg.ebank.model.Customer;

public interface IDao {

	int createCustomer(Customer customer, Account account);

	public double showBalance(int accountId);

	ArrayList getAllAccountDetails(int accountId);

	ArrayList getAllTransactionDetails(int accountId);

	ArrayList getAllCustomer(int accountId);

	double updateBalance(int amt, int accountId, double balance, String transactiontype);

}