/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: Dao Class of ebank.	
 */
package com.cg.ebank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import com.cg.ebank.helper.DBConnection;
import com.cg.ebank.helper.QueryMapper;
import com.cg.ebank.model.Account;
import com.cg.ebank.model.Customer;
import com.cg.ebank.model.Transaction;

public class DAOClass implements IDao {

	private Connection connection;
	private PreparedStatement preaparedStatement;
	private ResultSet resultSet;
	Random random = new Random();
	double balance;

	@Override
	public int createCustomer(Customer customer, Account account) {
		try {
			connection = DBConnection.getConnection();
			int accountid = (int) ((Math.random() * 100) * random.nextInt(1000));

			preaparedStatement = connection.prepareStatement("insert into customers values(" + accountid + ",?,?)");
			preaparedStatement.setString(1, customer.getCustName());
			preaparedStatement.setDouble(2, customer.getCustPhoneNum());

			int row = preaparedStatement.executeUpdate();
			System.out.println("hello");
			Account a = new Account();
			a.setAccountId(accountid);
			System.out.println("Your Account ID: " + a.getAccountId());
			// System.out.println("Customer Details created");

			preaparedStatement = connection.prepareStatement("insert into account values(" + accountid + ",?,?,?)");
			preaparedStatement.setString(1, account.getAccountholdername());
			preaparedStatement.setString(3, account.getAccountType());
			preaparedStatement.setDouble(2, account.getBalance());
			row = preaparedStatement.executeUpdate();
			// System.out.println("Customer Details created");
			preaparedStatement = connection.prepareStatement(
					"insert into transactions(ACCOUNTID,CREDITAMOUNT,TOTALBALANCE,TRANSACTIONTYPE) values(" + accountid
							+ ",?,?,'deposit')");

			// transaction
			preaparedStatement.setDouble(1, account.getBalance());
			preaparedStatement.setDouble(2, account.getBalance());
			row = preaparedStatement.executeUpdate();
			System.out.println("transaction details are updated");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 1;
	}

	public ArrayList<Customer> getAllCustomer(int accountId) {
		ArrayList<Customer> custList = new ArrayList<>();
		try {
			connection = DBConnection.getConnection();
			preaparedStatement = connection.prepareStatement(QueryMapper.INSERT_CUSTOMERS + accountId);
			resultSet = preaparedStatement.executeQuery();
			while (resultSet.next()) {
				Customer c = new Customer();
				c.setCustPhoneNum(resultSet.getLong(3));
				c.setAccountId(resultSet.getInt(1));
				// c.setCustName(rs.getString(2));
				// c.setCustEmail(rs.getString(3));
				custList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return custList;
	}

	public ArrayList<Account> getAllAccountDetails(int accountId) {
		ArrayList<Account> accList = new ArrayList<>();
		try {
			connection = DBConnection.getConnection();
			preaparedStatement = connection.prepareStatement(QueryMapper.INSERT_ACCOUNTDETAILS + accountId);
			resultSet = preaparedStatement.executeQuery();
			while (resultSet.next()) {
				Account a = new Account();
				a.setAccountholdername(resultSet.getString(2));
				a.setAccountId(accountId);
				a.setAccountType(resultSet.getString(4));
				a.setBalance(resultSet.getDouble(3));
				accList.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accList;
	}

	// Show the Balance
	@Override
	public double showBalance(int accountId) {
		connection = DBConnection.getConnection();
		try {
			preaparedStatement = connection.prepareStatement(QueryMapper.SHOW_BALANCE + accountId);
			resultSet = preaparedStatement.executeQuery();
			while (resultSet.next()) {
				balance = resultSet.getDouble("BALANCE");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return balance;
	}

	@Override
	public double updateBalance(int amt, int accountId, double balance, String transactiontype) {
		connection = DBConnection.getConnection();
		int l = 0;
		try {
			preaparedStatement = connection
					.prepareStatement("update account set balance =" + balance + "where accountid =" + accountId);
			l = preaparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (transactiontype.equals("credit")) {
			try {
				preaparedStatement = connection.prepareStatement(
						"insert into transactions(accountid, creditamount, totalbalance, transactiontype) values("
								+ accountId + "," + amt + "," + balance + ",'deposited')");
				resultSet = preaparedStatement.executeQuery();
			} catch (SQLException e) {
				System.out.println("Account Not Found");
			}
		} else if (transactiontype.contains("debit")) {
			try {
				preaparedStatement = connection.prepareStatement(
						"insert into transactions(accountid, debitamount, totalbalance, transactiontype) values("
								+ accountId + "," + amt + "," + balance + ",'withdrawn')");
				resultSet = preaparedStatement.executeQuery();
			} catch (SQLException e) {
				System.out.println("Account Not Found");
			}
		} else if (transactiontype.contains("transfer")) {
			try {
				preaparedStatement = connection.prepareStatement(
						"insert into transactions(accountid, debitamount, totalbalance, transactiontype) values("
								+ accountId + "," + amt + "," + balance + ",'transfered')");
				resultSet = preaparedStatement.executeQuery();
			} catch (SQLException e) {
				System.out.println("Account Not Found");
			}
		} else if (transactiontype.contains("transfered")) {
			try {
				preaparedStatement = connection.prepareStatement(
						"insert into transactions(accountid, creditamount, totalbalance, transactiontype) values("
								+ accountId + "," + amt + "," + balance + ",'received')");
				resultSet = preaparedStatement.executeQuery();
			} catch (SQLException e) {
				System.out.println("Account Not Found");
			}
		}
		return l;
	}

	@Override
	public ArrayList getAllTransactionDetails(int accountId) {
		ArrayList<Transaction> transactionList = new ArrayList<>();
		try {
			connection = DBConnection.getConnection();
			preaparedStatement = connection.prepareStatement("select * from transactions where accountId=" + accountId);
			resultSet = preaparedStatement.executeQuery();
			while (resultSet.next()) {
				Transaction transaction = new Transaction();
				transaction.setAccountId(resultSet.getInt(1));

				transaction.setCredit(resultSet.getInt(2));
				transaction.setDebit(resultSet.getInt(3));
				transaction.setTotal(resultSet.getInt(4));
				transaction.setTransType(resultSet.getString(5));
				transactionList.add(transaction);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return transactionList;
	}

}
