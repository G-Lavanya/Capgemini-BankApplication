/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: ACCOUNT POJO 
 */
package com.cg.ebank.model;

public class Account {
	private String accountholdername;
	private int accountId;
	private String accountType;
	private double balance;
	private double updatedBalance;

	public long getAccountId() {
		// System.out.println(accountId);
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountholdername() {
		return accountholdername;
	}

	public void setAccountholdername(String accountholdername) {
		this.accountholdername = accountholdername;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "AccountHolderName: " + accountholdername + ", AccountId: " + accountId + ", AccountType: " + accountType
				+ ", Balance: " + balance;
	}

	public double getUpdatingAmount(int amt, double availableBalance) {
		updatedBalance = amt + availableBalance;
		return updatedBalance;
	}

	public double getBalanceafterDeduction(int amt, double availableBalance) {
		updatedBalance = availableBalance - amt;
		return updatedBalance;
	}

}
