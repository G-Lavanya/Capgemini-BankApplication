/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: TRANSACTION POJO	
 */
package com.cg.ebank.model;

public class Transaction {
	private int accountId;
	private double balance;
	private int credit;
	private int debit;
	private int Total;
	private String transType;

	@Override
	public String toString() {
		return "Transaction [accountId=" + accountId + ", balance=" + balance + ", credit=" + credit + ", debit="
				+ debit + ", Total=" + Total + ", transType=" + transType + "]";
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double accBalance) {
		this.balance = accBalance;
	}

	public int getCredit() {
		return credit;
	}

	public void setCredit(int credit) {
		this.credit = credit;
	}

	public int getDebit() {
		return debit;
	}

	public void setDebit(int debit) {
		this.debit = debit;
	}

	public int getTotal() {
		return Total;
	}

	public void setTotal(int total) {
		Total = total;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}
}
