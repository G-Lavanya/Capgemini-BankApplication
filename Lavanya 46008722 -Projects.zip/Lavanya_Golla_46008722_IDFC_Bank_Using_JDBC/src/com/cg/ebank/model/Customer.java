/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :18/10/2019
 *
 *Description: CUSTOMER POJO	
 */
package com.cg.ebank.model;

public class Customer {

	private long custPhoneNum;
	private int accountId;
	private String custName;

	@Override
	public String toString() {
		return "Customer [custPhoneNum=" + custPhoneNum + ", accountId=" + accountId + "]";
	}

	public Customer() {
		super();
		this.custPhoneNum = custPhoneNum;
		// this.accountId = accountId;
		this.custName = custName;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public double getCustPhoneNum() {
		return custPhoneNum;
	}

	public void setCustPhoneNum(long custPhoneNum) {
		this.custPhoneNum = custPhoneNum;
	}

	public String getCustName() {

		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

}
