/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :12/05/2019
 *
 *Description: Exception class
 */

package com.cg.bankapp.exception;

public class BankException extends Exception {
public BankException()
{
	super();
}
public BankException(String msg)
{
	super(msg);
}
}

