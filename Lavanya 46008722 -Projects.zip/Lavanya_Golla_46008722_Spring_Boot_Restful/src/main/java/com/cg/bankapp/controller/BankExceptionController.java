/**
 * 
 *@Author: G.LAVANYA	
 *
 *Date :12/05/2019
 *
 *Description: Bank Exception ControllSSSer class
 */



package com.cg.bankapp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.bankapp.exception.BankException;
@ControllerAdvice
public class BankExceptionController
{
	@ExceptionHandler(BankException.class)
	public ResponseEntity<String> handleException(Exception ex)
	{
		return new ResponseEntity<String> ("Error: "+ex.getMessage(),HttpStatus.CONFLICT);
	}
}

