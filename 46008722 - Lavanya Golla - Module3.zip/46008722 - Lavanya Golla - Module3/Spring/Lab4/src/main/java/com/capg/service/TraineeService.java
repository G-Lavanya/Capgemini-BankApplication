package com.capg.service;

import java.util.List;

import com.capg.bean.Trainee;

public interface TraineeService {
	
	public void insertTrainee(Trainee trainee);

	public void updateTrainee(Trainee trainee);

	public Trainee getTrainee(int traineeId);

	public List<Trainee> getAllTrainee();
	
	public void deleteTrainee(int traineeId);

}
