package com.spg.DAO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.spg.Employee;
@Repository
public class EmployeeDAO {
	
	
	
	private List<Employee> list = new ArrayList<Employee>();
	
	
	
	
	public List<Employee> getList() {
		return list;
	}




	public void setList(List<Employee> list) {
		this.list = list;
	
	}




	public Employee findEmp(int id){
		
		Iterator iterator = list.iterator();
		while(iterator.hasNext()){
			Employee emp = (Employee) iterator.next();
			if(emp.getEmpId() == id){
				System.out.println(emp);
				return emp;
			}
		}
		return null;
	}
	
}
