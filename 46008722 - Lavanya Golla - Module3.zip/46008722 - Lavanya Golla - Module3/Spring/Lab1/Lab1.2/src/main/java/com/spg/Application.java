package com.spg;

import org.mockito.internal.invocation.finder.AllInvocationsFinder;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Application.class, args);
		Employee emp = context.getBean(Employee.class);
		SBU sbu = context.getBean(SBU.class);
		
		sbu.setSbuHead("Ram");
		sbu.setSbuId(1);
		sbu.setSbuName("Product Engineering Services");
		
		emp.setEmployeeId(12345);
		emp.setEmployeeName("Harriet");
		emp.setSalary(40000);
		emp.setBusinessUnit("PES-BU");
		emp.setAge(40);
		emp.setSbudetails(sbu);
	
		
		
		System.out.println(emp);
		
	}

}
