package com.cg;

public interface CustomerService {

	public String find(int id);
	
}
