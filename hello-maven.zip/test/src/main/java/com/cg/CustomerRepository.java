package com.cg;

public interface CustomerRepository {

	public String findById(int id);
}
