package com.cg;

public class Entry {

	
	public static void main(String[] args) {
		
		CustomerService service = new CustomerServiceImpl();
		
		String name = service.find(4);
		
		System.out.println(name);
		
	}
	
}
