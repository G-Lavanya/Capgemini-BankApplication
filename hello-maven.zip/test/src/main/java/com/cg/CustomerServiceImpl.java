package com.cg;

public class CustomerServiceImpl implements CustomerService {

	private CustomerRepository repo;
	
	public CustomerServiceImpl() {

		repo = new JDBCCustomerRepositoryImpl();
	}
	
	
	
	@Override
	public String find(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}
	
}
